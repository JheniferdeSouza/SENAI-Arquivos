/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mercadinhogosling;

import view.*;

/**
 *
 * @author senai
 */
public class MercadinhoGosling {

    public static void main(String[] args) {
      
      ViewLogin LoginObject = new ViewLogin();
      LoginObject.setVisible(true);
    }
}
